<?php if (isset($component)) { $__componentOriginal5bbdc712323ef87871f24f799bf398da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bbdc712323ef87871f24f799bf398da = $attributes; } ?>
<?php $component = App\View\Components\Admin\Wrapper::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Wrapper::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="section-title w-[fit-content] mx-auto">
        <h1 class="py-2 text-xl uppercase mx-auto px-4">
            Home
        </h1>
        <div class="hr h-[1px] bg-gray-400"></div>
    </div>
    <div class="container grid grid-cols-2 gap-4">
        <div class="buuble w-full h-40 bg-green-400 border rounded-xl">

        </div>

        <div class="buuble w-full h-40 bg-sky-400 border rounded-xl">

        </div>

        <div class="buuble col-span-2 w-full h-40 bg-sky-400 border rounded-xl">

        </div>

        <div class="buuble w-full h-40 bg-green-400 border rounded-xl">

        </div>

        <div class="buuble w-full h-40 bg-sky-400 border rounded-xl">

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bbdc712323ef87871f24f799bf398da)): ?>
<?php $attributes = $__attributesOriginal5bbdc712323ef87871f24f799bf398da; ?>
<?php unset($__attributesOriginal5bbdc712323ef87871f24f799bf398da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bbdc712323ef87871f24f799bf398da)): ?>
<?php $component = $__componentOriginal5bbdc712323ef87871f24f799bf398da; ?>
<?php unset($__componentOriginal5bbdc712323ef87871f24f799bf398da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\Chaima\resources\views/admin/home.blade.php ENDPATH**/ ?>