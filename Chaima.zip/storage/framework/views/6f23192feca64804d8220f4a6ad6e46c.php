<?php if (isset($component)) { $__componentOriginal5bbdc712323ef87871f24f799bf398da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bbdc712323ef87871f24f799bf398da = $attributes; } ?>
<?php $component = App\View\Components\Admin\Wrapper::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Wrapper::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="section-title w-[fit-content] mx-auto">
        <h1 class="py-2 text-xl uppercase mx-auto px-4">
            new etudiant
        </h1>
        <div class="hr h-[1px] bg-gray-400"></div>
    </div>

    <div class="container drop-shadow-lg mt-2 mx-auto w-full md:w-4/5 bg-[#f5f5f5] rounded-lg p-2">
        <form action="<?php echo e(route('admin.create.etudiant')); ?>" class="mx-auto" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-errors my-2"></div>
            <div class="inputs">
                <div class="inpt my-4 w-full">
                    <div class="hi m-auto w-4/5 relative">
                        <label for="matricule" class="block text-gray-500">name:</label>
                        <input id="matricule" placeholder="matricule..." type="text" name="matricule"
                            class="border-b border-l bg-transparent focus:bg-white border-sky-300 focus:border focus:border-sky-500 duration-150 ease-in-out outline-none h-10 px-4 w-full">
                    </div>
                    <?php $__errorArgs = ['matricule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-center text-red-400 font-medium">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="inpt my-4 w-full">
                    <div class="hi m-auto w-4/5 relative">
                        <label for="name" class="block text-gray-500">name:</label>
                        <input id="name" placeholder="name..." type="text" name="name"
                            class="border-b border-l bg-transparent focus:bg-white border-sky-300 focus:border focus:border-sky-500 duration-150 ease-in-out outline-none h-10 px-4 w-full">
                    </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-center text-red-400 font-medium">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="inpt my-4 w-full text-center">
                    <select class="m-auto w-4/5 border-b border-l bg-transparent focus:bg-white border-sky-300 focus:border focus:border-sky-500 duration-150 ease-in-out outline-none h-10 px-4 " name="branch_name" id="branch_name">
                        <option value="none" selected disabled>chose branch name</option>
                    </select>
                    <?php $__errorArgs = ['branch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-center text-red-400 font-medium">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="inpt my-4 w-full">
                    <div class="hi m-auto w-4/5 relative">
                        <label for="name" class="block text-gray-500">email:</label>
                        <input id="email" placeholder="email..." type="email" name="email"
                            class="border-b border-l bg-transparent focus:bg-white border-sky-300 focus:border focus:border-sky-500 duration-150 ease-in-out outline-none h-10 px-4 w-full">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-center text-red-400 font-medium">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="inpt my-4 w-full">
                    <div class="hi m-auto w-4/5 relative">
                        <label for="password" class="block text-gray-500">password:</label>
                        <input id="password" placeholder="password..." type="password" name="password"
                            class="border-b border-l bg-transparent focus:bg-white border-sky-300 focus:border focus:border-sky-500 duration-150 ease-in-out outline-none h-10 px-4 w-full">
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-center text-red-400 font-medium">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="inpt my-4 w-full">
                    <div class="hi m-auto w-4/5 relative">
                        <label for="bac_note" class="block text-gray-500">bac_note:</label>
                        <input id="bac_note" placeholder="bac note..." type="number" min="0" name="bac_note"
                            class="border-b border-l bg-transparent focus:bg-white border-sky-300 focus:border focus:border-sky-500 duration-150 ease-in-out outline-none h-10 px-4 w-full">
                    </div>
                    <?php $__errorArgs = ['bac_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-center text-red-400 font-medium">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
            </div>
            <div class="text-center my-4 w-4/5 mx-auto flex flex-col items-center justify-center">
                <button
                    class="w-4/5 mx-auto bg-green-500 text-white py-2 rounded-lg hover:bg-green-700 duration-300 ease-in-out">
                    <i class="bi bi-person-plus mr-2"></i>
                    create etudiant
                </button>
            </div>
        </form>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bbdc712323ef87871f24f799bf398da)): ?>
<?php $attributes = $__attributesOriginal5bbdc712323ef87871f24f799bf398da; ?>
<?php unset($__attributesOriginal5bbdc712323ef87871f24f799bf398da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bbdc712323ef87871f24f799bf398da)): ?>
<?php $component = $__componentOriginal5bbdc712323ef87871f24f799bf398da; ?>
<?php unset($__componentOriginal5bbdc712323ef87871f24f799bf398da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Chaima\resources\views/admin/create-etudiant.blade.php ENDPATH**/ ?>