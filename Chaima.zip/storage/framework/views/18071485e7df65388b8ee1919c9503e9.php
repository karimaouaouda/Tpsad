<?php if (isset($component)) { $__componentOriginal5bbdc712323ef87871f24f799bf398da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bbdc712323ef87871f24f799bf398da = $attributes; } ?>
<?php $component = App\View\Components\Admin\Wrapper::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Wrapper::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         
    <div class="section-title w-[fit-content] mx-auto">
        <h1 class="py-2 text-xl uppercase mx-auto px-4">
            etudiants list
        </h1>
        <div class="hr h-[1px] bg-gray-400"></div>
    </div>

    <div class="w-full flex justify-center">
        <div class="container flex justify-center mx-auto">
            <div class="flex flex-col">
                <div class="w-full">
                    <div class="border-b border-gray-200 shadow">
                        <table class="divide-y divide-gray-300 ">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-2 text-xs text-gray-500">
                                        ID
                                    </th>
                                    <th class="px-6 py-2 text-xs text-gray-500">
                                        Name
                                    </th>
                                    <th class="px-6 py-2 text-xs text-gray-500">
                                        Email
                                    </th>
                                    <th class="px-6 py-2 text-xs text-gray-500">
                                        Created_at
                                    </th>
                                    <th class="px-6 py-2 text-xs text-gray-500">
                                        Edit
                                    </th>
                                    <th class="px-6 py-2 text-xs text-gray-500">
                                        Delete
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-300">
                                
                                <?php if(count($etudiants) > 0): ?>
                                    <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="whitespace-nowrap">
                                        <td class="px-6 py-4 text-sm text-gray-500">
                                            1
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="text-sm text-gray-900">
                                                Jon doe
                                            </div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="text-sm text-gray-500">jhondoe@example.com</div>
                                        </td>
                                        <td class="px-6 py-4 text-sm text-gray-500">
                                            2021-1-12
                                        </td>
                                        <td class="px-6 py-4">
                                            <a href="#" class="px-4 py-1 text-sm text-indigo-600 bg-indigo-200 rounded-full">Edit</a>
                                        </td>
                                        <td class="px-6 py-4">
                                            <a href="#" class="px-4 py-1 text-sm text-red-400 bg-red-200 rounded-full">Delete</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td class="text-center" colspan="6">
                                            sorry no etudiant found, 
                                            <a class="underline text-sky-500" href="<?php echo e(route('admin.create.etudiant')); ?>">create one</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bbdc712323ef87871f24f799bf398da)): ?>
<?php $attributes = $__attributesOriginal5bbdc712323ef87871f24f799bf398da; ?>
<?php unset($__attributesOriginal5bbdc712323ef87871f24f799bf398da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bbdc712323ef87871f24f799bf398da)): ?>
<?php $component = $__componentOriginal5bbdc712323ef87871f24f799bf398da; ?>
<?php unset($__componentOriginal5bbdc712323ef87871f24f799bf398da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\Chaima\resources\views/admin/etudiants-list.blade.php ENDPATH**/ ?>