<x-admin.wrapper>
    <div class="section-title w-[fit-content] mx-auto">
        <h1 class="py-2 text-xl uppercase mx-auto px-4">
            Home
        </h1>
        <div class="hr h-[1px] bg-gray-400"></div>
    </div>
    <div class="container grid grid-cols-2 gap-4">
        <div class="buuble w-full h-40 bg-green-400 border rounded-xl">

        </div>

        <div class="buuble w-full h-40 bg-sky-400 border rounded-xl">

        </div>

        <div class="buuble col-span-2 w-full h-40 bg-sky-400 border rounded-xl">

        </div>

        <div class="buuble w-full h-40 bg-green-400 border rounded-xl">

        </div>

        <div class="buuble w-full h-40 bg-sky-400 border rounded-xl">

        </div>
    </div>
</x-admin.wrapper>